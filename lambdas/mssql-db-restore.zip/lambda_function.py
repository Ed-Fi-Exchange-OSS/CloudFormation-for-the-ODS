import time
import boto3
import pyodbc
import signal
import traceback
from crhelper import CfnResource

helper = CfnResource()

def lambda_handler(event, context):
    signal.alarm(int((context.get_remaining_time_in_millis() / 1000) - 1))
    helper(event, context)

@helper.create
def create(event, _):
  SOURCE    = event['ResourceProperties']['source']
  SERVER    = event['ResourceProperties']['server']
  DATABASE  = event['ResourceProperties']['database']
  USERNAME  = event['ResourceProperties']['username']
  PWD_NAME  = event['ResourceProperties']['pwdname']

  try:
    # When we return to pullng the password from SSM we can uncomment this again.
    #ssm_client  = boto3.client('ssm')
    #PASSWORD    = ssm_client.get_parameter(Name=PWD_NAME, WithDecryption=True)['Parameter']['Value']    
    PASSWORD    = PWD_NAME  

    conn	          = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+SERVER+';UID='+USERNAME+';PWD='+PASSWORD)
    conn.autocommit = True
    cursor 	        = conn.cursor()

    QUERY       = "DROP DATABASE IF EXISTS " + DATABASE 

    conn.execute(QUERY)

    time.sleep(10)

    print("Setting up to restore the database..")
    print(DATABASE)

    QUERY       = "exec msdb.dbo.rds_restore_database @restore_db_name='" + DATABASE + "', @s3_arn_to_restore_from='" + SOURCE + "';"

    conn.execute(QUERY)
    
    QUERY	      = "exec msdb.dbo.rds_task_status @db_name='" + DATABASE + "';"
    # Refer to: https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/SQLServer.Procedural.Importing.html
    STATUS      = ''
    INFO        = ''
    count       = 0
    
    while STATUS != 'SUCCESS' or count < 8:
      result    = cursor.execute(QUERY)
      row       = cursor.fetchone()

      STATUS    = row[5]
      print(STATUS)
      print(row)     

      if STATUS == 'ERROR':
        INF0    = row[6]
        count   = 8

      time.sleep(10)
      count     = count + 1
      print(count)
      
    if STATUS == 'SUCCESS':
      print('SUCCESS')
    else:
      print('INFO')
      
    cursor.close()
    del cursor

    # Close Connection
    conn.close()
 
  except:
    traceback.print_exc()

@helper.update
@helper.delete
def no_op(_, __):
  pass

def timeout_handler(_signal, _frame):
    '''Handle SIGALRM'''
    raise Exception('Time exceeded')

signal.signal(signal.SIGALRM, timeout_handler)
