import boto3
import signal
from crhelper import CfnResource

helper = CfnResource()

def lambda_handler(event, context):
    signal.alarm(int((context.get_remaining_time_in_millis() / 1000) - 1))
    helper(event, context)

@helper.create
def create(event, _):
    REGION          = event['ResourceProperties']['region']
    BUCKET_NAME     = event['ResourceProperties']['bucket_name']
    KEY_PAIR_NAME   = event['ResourceProperties']['key_pair_name']

    key_exists      = check_for_key(KEY_PAIR_NAME)
    
    if not key_exists:
        key_pair        = create_key_pair(KEY_PAIR_NAME)
    
        upload_key_pair(key_pair, KEY_PAIR_NAME, BUCKET_NAME)
    
    helper.Data['KeyPairName'] = KEY_PAIR_NAME

def check_for_key(key_pair_name):
    ec2             = boto3.client('ec2')
    response        = ec2.describe_key_pairs()

    found = False
    
    for key in response['KeyPairs']:
        if key['KeyName'] == key_pair_name:
            found = True
    
    return found

def create_key_pair(key_pair_name):
    ec2             = boto3.client('ec2')
    response        = ec2.create_key_pair(
        KeyName=key_pair_name
    )
    
    return str(response['KeyMaterial'])

def upload_key_pair(key_pair, key_pair_name, bucket_name):
    s3              = boto3.resource('s3')
    s3.Object(bucket_name, key_pair_name).put(Body=key_pair, ContentType='application/x-pem-file')

@helper.delete    
@helper.update
def no_op(_, __):
    pass

    

def timeout_handler(_signal, _frame):
    '''Handle SIGALRM'''
    raise Exception('Time exceeded')

signal.signal(signal.SIGALRM, timeout_handler)