import os
import json
import boto3
import signal
import psycopg2
import traceback
import subprocess
from crhelper import CfnResource

helper = CfnResource()

def lambda_handler(event, context):
    signal.alarm(int((context.get_remaining_time_in_millis() / 1000) - 1))
    helper(event, context)

## The Lambda funtion will need to have the following setup:
##   1.) Environment Variable set to the following:  PGPASSFILE = /tmp/.pgpass
##   2.) Max execution time of 1 min as the SQL import takes some time
##   3.) The SQL file to import in S3 as hardcoded in the function below

### We are going to run our own binary, so we need to set the path to it and link a library
### This *must* be done at the start of the Lambda function here.
os.environ['PATH'] = os.environ['PATH'] + ":" + os.environ['LAMBDA_TASK_ROOT']
os.environ['LD_LIBRARY_PATH'] = os.environ['LD_LIBRARY_PATH'] + ":" + os.environ['LAMBDA_TASK_ROOT']

def lambda_handler(event,context):
    signal.alarm(int((context.get_remaining_time_in_millis() / 1000) - 1))
    helper(event, context)
        
@helper.create
def create(event, _):    
    BUCKET      = event['ResourceProperties']['bucket']
    BUCKET_KEY  = event['ResourceProperties']['bucket_key']
    SERVER      = event['ResourceProperties']['server']
    DATABASE    = event['ResourceProperties']['database']
    USERNAME    = event['ResourceProperties']['username']
    PASSWORD    = event['ResourceProperties']['password']
    REGION      = event['ResourceProperties']['region']
    
    ## Download SQL file from S3
    download_s3_file_to_client_local_directory(BUCKET, BUCKET_KEY, "/tmp/import_file.sql")
   
    print('SQL file downloaded')
    
    ## Set the .pgpass values and perms that we will use to connect to a database 
    subprocess.call("touch /tmp/.pgpass", shell=True)
    pgpass_file = "echo '*:*:*:" + USERNAME + ":" + PASSWORD + "' > /tmp/.pgpass"
    subprocess.call(pgpass_file, shell=True)
    subprocess.call("chmod 600 /tmp/.pgpass", shell=True)
    
    ## Copy the PSQL binary we need to use to /tmp so that we can set perms
    subprocess.call("cp psql /tmp", shell=True)
    subprocess.call("chmod 755 /tmp/psql", shell=True)

    ## Create the Database in PostgreSQL
    db_create_query = "/tmp/psql -U " + USERNAME + " -h " + SERVER + " -w -c \'CREATE DATABASE \"" + DATABASE + "\"\'\;"
    print('Creating database: ' + db_create_query)
    psql_query = subprocess.check_output(db_create_query, shell=True)
    print('Create database command successfully executed')
    
    ## Import into the database the SSP Schema file
    import_query = "/tmp/psql -U " + USERNAME + " -h " + SERVER + " -w -d " + DATABASE + " < /tmp/import_file.sql"
    print('Importing database file: ' + import_query)
    psql_query = subprocess.check_output(import_query, shell=True)
    print('Import completed.  If an ERROR message above is shown for the pcrypto extension, this can be safely ignored.')
    
def download_s3_file_to_client_local_directory(bucket_name,key,filename):

    try:
        s3 = boto3.client('s3')

        print("Downloading file s3://" + bucket_name + "/" + key)

        s3.download_file(bucket_name,key,filename)

        return

    except:
        print("Something went wrong when downloading the schema file from s3://" + bucket_name + "/" + key)
        traceback.print_exc()
        exit(1)
       
@helper.update
@helper.delete
def no_op(_, __):
    pass
  
def timeout_handler(_signal, _frame):
    '''Handle SIGALRM'''
    raise Exception('Time exceeded')

signal.signal(signal.SIGALRM, timeout_handler)  

